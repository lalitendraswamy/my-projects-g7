// function handleRequest(controllerFunction) {
//     return async (req, res) => {
//         try {
//             // Execute the controller function and get the result
//             const result = await controllerFunction(req);

//             // Determine success status code based on HTTP method
//             let statusCode;
//             let message;

//             switch (req.method) { 
//                 case 'POST':
//                     statusCode = 201; // Created 
//                     message = 'Created successfully';
//                     break;
//                 case 'PUT':
//                     statusCode = 200; // OK
//                     message = 'Updated successfully';
//                     break;
//                 case 'DELETE':
//                     statusCode = 200; // OK
//                     message = 'Deleted successfully';
//                     break;
//                 default:
//                     statusCode = 200; // OK
//                     message = result;
//             }

//             // Send the response
//             res.status(statusCode).send(message);

//         } catch (err) {
//             console.error('Error:', err);

//             // Determine error status code
//             const { errorCode, errorMessage } = getErrorCodeAndMessage(err);

//             // Send the error response
//             res.status(errorCode).send({ error: errorMessage });
//         }
//     };
// }

// // Helper function to get the error code and message
// function getErrorCodeAndMessage(err) {
//     switch (err.name) {
//         case 'ValidationError':
//             return { errorCode: 400, errorMessage: err.message }; // Bad Request
//         case 'UnauthorizedError':
//             return { errorCode: 401, errorMessage: 'Unauthorized access' }; // Unauthorized
//         case 'NotFoundError':
//         case 'NotFoundException':
//             return { errorCode: 404, errorMessage: err.message }; // Not Found
//         default:
//             return { errorCode: 500, errorMessage: 'An internal error occurred' }; // Internal Server Error
//     }
// }

// module.exports = handleRequest;


const successObject = {
    'GET': 200,
    'POST': 201,
    'PATCH': 202,
    'PUT': 202,
    'DELETE': 204,
  };
 
  const errorObject = {
    'ValidationError': 400,
    'UnauthorizedError': 401,
    'NotFoundError': 404,
    'InternalServerError': 500,
  };
 
  function handleRequest(controllerFunction) {
    return async (request, response, next) => {
      try {
        const result = await controllerFunction(request, response, next);
        const method = request.method.toUpperCase();
        const statusCode = successObject[method] || 200;
        response.status(statusCode).send(result);
 
      } catch (error) {
        const statusCode = errorObject[error.name] || 500;
        const errorMessage = error.message || 'An unexpected error occurred';
        response.status(statusCode).send({
          error: error.name,
          message: errorMessage,
        });
      }
    };
  }
 
  module.exports = handleRequest;