
let NotFoundException = require('../../utils/not-found');
var {executor,connect} =require('../../connection');

var url='mongodb://localhost:27017';
var booksExecutor=executor(url, "g7cr_202408","books");





class InMemoryBookRepository{

    
    async getBooks(){
        
        return await booksExecutor(async (books)=>{
            return await books.find({}).toArray();
        })   
    } 


    async addBook(book){
        return await booksExecutor(async (books)=>{

            return await books.insertOne(book);
        })
    }


    async getBookById(book_id){
        
        return await booksExecutor(async (books)=>{

            return await books.find({id:book_id}).toArray();
        })
    }

    async updateBook(prevId,updatebookObj){
        return await booksExecutor(async (books)=>{

            return await books.updateOne(
                { id :prevId},
                { $set: updatebookObj}
            );
        })
    }

    async deleteBookById(id){
        
        return await booksExecutor(async (books)=>{

            return await books.deleteOne({ id });
        })
    }

    async getBookReviews(book_id) {
        return await booksExecutor(async (books) => {
            
            const book = await books.findOne({ id: book_id });           
            
            if (book && book.reviews) {
                return book.reviews;
            } 
        });
    }


    async addBookReview(book_id, review) {
        return await booksExecutor(async (books) => {
            // Update the book document by pushing the new review into the reviews array
            const result = await books.updateOne(
                { id: book_id }, // Match the book by its id
                {
                    $push: { reviews: review } // Add the new review to the reviews array
                }
            );
    
            // Check if the update was successful
            if (result.modifiedCount > 0) {
                return { success: true, message: 'Review added successfully' };
            } else {
                throw new NotFoundException("Book not found", { id: book_id });
            }
        });
    }
    
    


    async getbookBooks(id) {
        return await booksExecutor(async (books) => {
            return await books.aggregate([
                {
                    $match: { id: id }  // Match the book by id
                },
                {
                    $lookup: {
                        from: 'books',              // Collection to join with
                        localField: 'id',           // Field from the books collection
                        foreignField: 'bookId',   // Field from the books collection
                        as: 'book'           // Name of the array field to add to the output documents
                    }
                },
                {
                    $unwind: {
                        path: '$book',      // Deconstructs the array field bookDetails
                        preserveNullAndEmptyArrays: true  // Keep the book in the result even if they have no books
                    }
                },
                {
                    $project: {
                        'book.title':1,
                        _id:0
                    }
                }
            ]).toArray();
        });
    }


    async bookSearch(queryText) {
        return await booksExecutor(async (books) => {
            // Convert the queryText to a case-insensitive regular expression
            const searchRegex = new RegExp(queryText, 'i');
    
            return await books.find({
                $or: [
                    { name: searchRegex },         // Search in the 'name' field
                    { biography: searchRegex },    // Search in the 'biography' field
                    { id: searchRegex }            // Search in the 'id' field
                    // Add more fields here if needed
                ]
            }).toArray();
        });
    }
    
    async getReviewByBook(book_id, review_id) {
        return await booksExecutor(async (books) => {
            const book = await books.findOne({ id: book_id }, { projection: { reviews: 1 } });
    
            if (!book) {
                throw new NotFoundException("Book not found", { id: book_id });
            }
    
            const review = book.reviews.find(r => r._id === review_id);
    
            if (!review) {
                throw new NotFoundException("Review not found", { reviewId: review_id });
            }
    
            return review;
        });
    }
    
    async updateBookReviewById(book_id, review_id, updateReviewObj) {
        return await booksExecutor(async (books) => {
            return await books.updateOne(
                { id: book_id, "reviews.reviewId": review_id },
                { $set: updateReviewObj }
            );
    
            
        });
    }
    
    

}

module.exports=new InMemoryBookRepository();