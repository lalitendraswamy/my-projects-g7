
let NotFoundException = require('../../utils/not-found');
var {executor,connect} =require('../../connection');

var url='mongodb://localhost:27017';
var authorsExecutor=executor(url, "g7cr_202408","authors");





class InMemoryAuthorRepository{

    
    async getAllAuthors(){
        
        return await authorsExecutor(async (authors)=>{
            return await authors.find({}).toArray();
        })   
    } 


    async addAuthor(author){
        return await authorsExecutor(async (authors)=>{

            return await authors.insertOne(author);
        })
    }


    // async function getCheckAuthors(authors){
    //     return await authorsExecutor(async authors=>{
    //      return await authors.find({});
    //     });
    //  }

    async getAuthorById(aid){
        
        return await authorsExecutor(async (authors)=>{

            return await authors.find({id:aid}).toArray();
        })
    }

    async updateAuthor(prevId,updateAuthorObj){
        return await authorsExecutor(async (authors)=>{

            return await authors.updateOne(
                { id :prevId},
                { $set: updateAuthorObj}
            );
        })
    }

    async deleteAuthorById(id){
        
        return await authorsExecutor(async (authors)=>{

            return await authors.deleteOne({ id });
        })
    }

    async getAuthorBooks(id) {
        return await authorsExecutor(async (authors) => {
            return await authors.aggregate([
                {
                    $match: { id: id }  // Match the author by id
                },
                {
                    $lookup: {
                        from: 'books',              // Collection to join with
                        localField: 'id',           // Field from the authors collection
                        foreignField: 'authorId',   // Field from the books collection
                        as: 'book'           // Name of the array field to add to the output documents
                    }
                },
                {
                    $unwind: {
                        path: '$book',      // Deconstructs the array field bookDetails
                        preserveNullAndEmptyArrays: true  // Keep the author in the result even if they have no books
                    }
                },
                {
                    $project: {
                        'book.title':1,
                        _id:0
                    }
                }
            ]).toArray();
        });
    }


    async authorSearch(queryText) {
        return await authorsExecutor(async (authors) => {
            // Convert the queryText to a case-insensitive regular expression
            const searchRegex = new RegExp(queryText, 'i');
    
            return await authors.find({
                $or: [
                    { name: searchRegex },         // Search in the 'name' field
                    { biography: searchRegex },    // Search in the 'biography' field
                    { id: searchRegex }            // Search in the 'id' field
                    // Add more fields here if needed
                ]
            }).toArray();
        });
    }
    

    

}

module.exports=new InMemoryAuthorRepository();